package juego;

import java.awt.Color;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;

import entorno.Entorno;
import entorno.Herramientas;

public class Plataforma {
	// variables de Instancia
	Point punto;
	int x;
	int y;
	int alto;
	int ancho;
	private Image imagenPlataforma;
	Rectangle rectanguloPlataforma;

	// contructor
	public Plataforma(int x, int y) {
		this.x = x;
		this.y = y;
		this.punto = new Point(x,y);
		this.ancho = 220;
		this.alto = 25;
		this.rectanguloPlataforma = new Rectangle(punto.x, punto.y, this.ancho, this.alto);
		this.imagenPlataforma = Herramientas.cargarImagen("plataforma.png");
	}

	public void dibujarPlataforma(Entorno entorno) {
		entorno.dibujarRectangulo(x, y, rectanguloPlataforma.width, rectanguloPlataforma.height, 0, Color.black );
		entorno.dibujarImagen(imagenPlataforma, this.x, 400, 0.0, 0.4);
	}
	void moverAIzquierda( double velAvanceArbol ) {
		this.x -=velAvanceArbol;
		punto.x-=velAvanceArbol;
	}
	
	public Rectangle getEspPlataforma() {
		rectanguloPlataforma.x = punto.x;
		rectanguloPlataforma.y = punto.y;
		
		return this.rectanguloPlataforma;
	}
}