package juego;

import java.awt.*;
import entorno.*;

public class Arbol {
	Point punto;
	private Image arbol;
	
public Arbol(int x, int y) {
	this.punto = new Point(x,y);
	this.arbol = Herramientas.cargarImagen("arbol.png");
}
	
public void dibujarse(Entorno entorno) {
	entorno.dibujarImagen(arbol, this.punto.x, 380, 0, 0.35);
}

void moverIzquierda() {
	this.punto.x -=1.5;
	}
}
