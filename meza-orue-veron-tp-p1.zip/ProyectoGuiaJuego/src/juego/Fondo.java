package juego;

import java.awt.*;
import entorno.*;

public class Fondo {
	private Image pastoFijo;
	private Image fondoAzul;
	private Point posicion;

public Fondo() {
	this.pastoFijo = Herramientas.cargarImagen("pastoFijo-1.png");
	fondoAzul = Herramientas.cargarImagen("fondo-celeste.png");
	this.posicion = new Point (0,400);
	}

public void dibujar(Entorno entorno, int rotacion) {
	entorno.dibujarImagen(fondoAzul, 250, 270, rotacion, 2.1);
	entorno.dibujarImagen(pastoFijo, 350, 625, rotacion, 0.5);
	}
}

