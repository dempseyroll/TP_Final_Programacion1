package juego;

import java.awt.Color;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;

import entorno.Entorno;
import entorno.Herramientas;

public class Mono 
{
	// Variables de instancia
	int x;
	int y;
	double angulo;
	Image img1;
	int piso = 520;
	Point punto;
	Rectangle rectanguloMono;
	int sePresiono = 0;
	int volviendo;

	
	public Mono(int x, int y) 
	{
		this.x = x;
		this.y = y;
		this.punto = new Point(x,y);
		this.rectanguloMono= new Rectangle(this.punto.x, this.punto.y, 40, 60);

		img1 = Herramientas.cargarImagen("mono.png");
		
	}
	
	public void dibujarse(Entorno entorno)
	{
		//entorno.dibujarRectangulo(this.x  , this.y , rectanguloMono.width, rectanguloMono.height, 0, Color.black );
		
		entorno.dibujarImagen(img1, this.x, this.y, this.angulo, 0.12);

	}

	
	public void saltando(int saltY) {		
		this.y-=saltY;
	}
	
	public void vuelvePiso(int volviendo) {

		if( this.y < volviendo ) {
			this.y+=10;
		}
	}
	
	
	//colision referencia
	public boolean colision( Rectangle rectanguloPlat ) {
		//if ( (this.spawn.x + (rectanguloPiedra.width/2 ) >= rectanguloDepred.x +  ( rectanguloDepred.width/2 ) ) && ( this.spawn.y+ (rectanguloPiedra.height/2) >=  rectanguloDepred.y + ( rectanguloDepred.width/2 )  ) ) {
		int espacioMonoX = this.x + (rectanguloMono.width/2 );
		int espacioPlatX = rectanguloPlat.x -  ( rectanguloPlat.width/2 );
		int espacioMonoY = this.y + (rectanguloMono.height/2);
		int espacioPlatY = rectanguloPlat.y - ( rectanguloPlat.width );
			
		if ( (espacioMonoX > espacioPlatX ) && ( espacioMonoY >  espacioPlatY ) ) {
//		if ( (rectanguloMono.wih >= espacioPlatX ) && ( espacioMonoY >=  espacioPlatY ) ) {	
			return true;		 
		}
		return false;	 
		}
	
}