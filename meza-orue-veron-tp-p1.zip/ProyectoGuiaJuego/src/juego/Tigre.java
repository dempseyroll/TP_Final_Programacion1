package juego;

import java.awt.*;
import entorno.*;

public class Tigre {
	Point punto;
	private Image tigre;
	Rectangle rectanguloTigre;
	
public Tigre(int x, int y) {
	this.punto = new Point(x,y);
	this.rectanguloTigre = new Rectangle(punto.x, punto.y, 140, 90);
	this.tigre = Herramientas.cargarImagen("tigre.png");
}	

public void dibujarse(Entorno entorno) {
	entorno.dibujarImagen(tigre, this.punto.x, this.punto.y, 0, 0.3);
//	entorno.dibujarRectangulo(punto.x, punto.y, rectanguloTigre.width, rectanguloTigre.height, 0, Color.black);
}

void moverIzquierda() {
	this.punto.x -=5;
}

public Rectangle getEspTigre() {
	rectanguloTigre.x = punto.x;
	rectanguloTigre.y = punto.y;
	
	return this.rectanguloTigre;
}

}
