package juego;


import java.awt.Color;

//import javax.sound.sampled.Clip;

//import entorno.Entorno;
//import entorno.Herramientas;
//import entorno.InterfaceJuego;
import entorno.*;

public class Juego extends InterfaceJuego
{
	// El objeto Entorno que controla el tiempo y otros
	private Entorno entorno;
	// otras variables del juego aqui
	

	
	// Variables y métodos propios de cada grupo
	// ...
	//fondo
	private Fondo fondo = new Fondo();
	Pasto pasto []= new Pasto[1];
	Mono mono;
	private Piedra piedra; 
	private Tigre tigre;
	int gravedadMono;
	int piso = 520;
	int pisoMono = 520;
	Tigre tigres[]  = new Tigre[3];
	Arbol arbol[]= new Arbol[2];
	Plataforma plataforma[]= new Plataforma[1];

	int miliSegundos;
	int minutos;
	int segundos;
	
	Temporizador tempo;
	int suma ;
	
	Juego()
	{
		// Inicializa el objeto entorno
		this.entorno = new Entorno(this, "Selva Mono Capuchino - Grupo 08 Elva-Pablo-Mati - v1", 800, 600);

		
		// Inicializa el objeto entorno, pero aun no lo inicia.
		
		mono = new Mono(50, piso);
		mono.dibujarse(entorno);
		gravedadMono	= 0;
		miliSegundos    = 0;
		int minutos		= 0;
		int segundos	= 0;
		
		pasto[0] = null ;
		
		arbol[0] = null ;
		arbol[1] = null ;
		plataforma[0]= null;

		this.piedra = null;
		this.tigre = null;
		
		tigres[0] = null;
		tigres[1] = null;

		
		tempo = new Temporizador(segundos);
				

		// Inicializar lo que haga falta para el juego
		// ...
		
		// El objeto Entorno que controla el tiempo y otros
		// ….
		Herramientas.loop("Sans.wav");

		// Inicia el juego!
		this.entorno.iniciar();		
	}

	/**
	 * Durante el juego, el método tick() será ejecutado en cada instante y 
	 * por lo tanto es el método más importante de esta clase. Aquí se debe 
	 * actualizar el estado interno del juego para simular el paso del tiempo 
	 * (ver el enunciado del TP para mayor detalle).
	 */
	public void tick()
	{
		// Procesamiento de un instante de tiempo

		tempo.tiempo();
		
		fondo.dibujar(entorno, 0);
		
//		//pasto
//		//pasto[0]
		if (this.pasto[0] == null) {
			//anda:
			this.pasto[0] = new Pasto(450, piso);
		}
		
		// pasto[0]

		if( (this.pasto[0] != null) && (pasto[0].punto.x < this.entorno.ancho()- this.entorno.ancho()+ 10.00) ) {
			this.pasto[0]=null;
		}
		
		//pasto[0]
		if(this.pasto[0] != null) {
			//pasto
			this.pasto[0].dibujarse(entorno);
			this.pasto[0].moverIzquierda();
			
		}	
		

//		limiteIz = this.entorno.ancho()- this.entorno.ancho()- 50.00);
		entorno.cambiarFont("Arial", 26, Color.white);
		entorno.escribirTexto("Tiempo: "+tempo.minutos + " : "+tempo.segundos ,500,200 );
		
		
		if (entorno.sePresiono(entorno.TECLA_ARRIBA) && mono.sePresiono < 1 ) {
			mono.sePresiono+=1;
			gravedadMono= 400;
			Herramientas.play("Salto.wav");
		}
			
		if( piso+gravedadMono > piso && mono.y > 150 && pisoMono+gravedadMono > piso ) {
			mono.saltando(10);
			gravedadMono-=10;
		}else{
			if ( mono != null && plataforma[0] != null && mono.colision(plataforma[0].getEspPlataforma()) && mono.sePresiono <= 2 && mono.x <= (plataforma[0].x + (plataforma[0].rectanguloPlataforma.height/2)) ) {
				pisoMono = plataforma[0].getEspPlataforma().y - (plataforma[0].rectanguloPlataforma.height) ; 
				mono.vuelvePiso(pisoMono);
			}else {
			gravedadMono = 0;
			mono.vuelvePiso(piso);
			}
		}
		
		
		if( mono.y == piso || mono.y == pisoMono ) {
			mono.sePresiono=0;
		}
		
		System.out.println( "eje Y monoY: "+mono.y );
		
		if (this.arbol[0] == null) {
			this.plataforma[0] = new Plataforma(this.entorno.ancho()+50, 400 );
			this.arbol[0] = new Arbol(this.entorno.ancho()+50, piso);
			
		}
		
		//arbol[0]
		if(this.arbol[0] != null) {
			//arbol
			this.arbol[0].dibujarse(entorno);
			this.arbol[0].moverIzquierda();
			
			//plataforma
			this.plataforma[0].dibujarPlataforma(entorno);
			this.plataforma[0].moverAIzquierda(1.5);
			
		}
//		System.out.println( "eje x plataforma: "+plataforma[0].getEspPlataforma().x );
		// arbol[0]
		if( (this.arbol[0] != null) && (arbol[0].punto.x < this.entorno.ancho()- this.entorno.ancho()- 150.00) ) {
			this.arbol[0]=null;
			this.plataforma[0]=null;
		}
		
		
		//Mono
//		System.out.println("gravedad mono: "+gravedadMono);
		mono.dibujarse(entorno);
		
					
		
		if (this.piedra == null && entorno.sePresiono(entorno.TECLA_ESPACIO)) {
			this.piedra = new Piedra(mono.x, mono.y);
		}
		
		
		if(this.piedra != null) {
			this.piedra.dibujarse(entorno);
			this.piedra.moverDerecha();
		}
		
		if( this.piedra != null && piedra.spawn.x > this.entorno.ancho()+50.00 )
			this.piedra=null;
		


		
		// Prueba end
		

		
		// tigre
		if (this.tigre == null) {
			this.tigre = new Tigre(this.entorno.ancho()+50, piso);
		}
		
		
//		tigres[0] = null;
		if (this.tigres[1] == null) {
			this.tigres[1] = new Tigre(this.entorno.ancho()+50, piso);
		}
		
		
		
//		tigres[0]
		if( (this.tigres[1] != null) && (tigre.punto.x <= 400 || this.tigres[1].punto.x <= 400) ){
			this.tigres[1].dibujarse(entorno);
			this.tigres[1].moverIzquierda();
		}
		//
		
		if(this.tigre != null) {
			this.tigre.dibujarse(entorno);
			this.tigre.moverIzquierda();
		}
		
		
//		tigres[0]
		if( (this.tigres[1] != null) && (tigres[1].punto.x < this.entorno.ancho()- this.entorno.ancho()- 50.00) )
			this.tigres[1]=null;
		
		
		if( (this.tigre != null) && (tigre.punto.x < this.entorno.ancho()- this.entorno.ancho()- 50.00) )
			this.tigre=null;
		
		
//		if (tigre != null && piedra != null && piedra.colision(tigre.getSpawn())) {
//			tigre=null;
//		}
		if ( tigre != null && piedra != null && piedra.colision(tigre.getEspTigre()) ) {
			tigre=null;
			piedra = null;
			Herramientas.play("Piedra.wav");
			suma = piedra.spawn.x + piedra.rectanguloPiedra.width/2;
		}
//		System.out.println( "piedra rectang.x: "+  suma );
//		piedra.spawn.x + piedra.rectanguloPiedra.width/2
//		System.out.println( "eje x tigre: "+tigres[1].rectanguloTigre.x );
	}
	

	@SuppressWarnings("unused")
	public static void main(String[] args)
	{
		Juego juego = new Juego();
	}
}
