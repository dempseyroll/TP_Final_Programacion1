package juego;

import java.awt.*;
import entorno.*;

public class Piedra {
	private Entorno entorno;
	Point spawn;
	Rectangle rectanguloPiedra;
	private Image piedra;
	
public Piedra(int x, int y) {
	this.spawn = new Point(x,y);
	this.rectanguloPiedra= new Rectangle(this.spawn.x, this.spawn.y, 20, 20);
	this.piedra = Herramientas.cargarImagen("piedra.png");
}


public void dibujarse(Entorno entorno) {
//	entorno.dibujarCirculo(spawn.x  , spawn.y , 60.0, Color.white );
	entorno.dibujarRectangulo(spawn.x, spawn.y, rectanguloPiedra.width, rectanguloPiedra.height, 0, null);
	entorno.dibujarImagen(piedra, this.spawn.x, this.spawn.y, 0, 0.056);
}

void moverDerecha() {
	this.spawn.x +=8;
}

public boolean colision( Rectangle rectanguloDepred ) {
//if ( (this.spawn.x + (rectanguloPiedra.width/2 ) >= rectanguloDepred.x +  ( rectanguloDepred.width/2 ) ) && ( this.spawn.y+ (rectanguloPiedra.height/2) >=  rectanguloDepred.y + ( rectanguloDepred.width/2 )  ) ) {
int espacioPiedraX = this.spawn.x + (rectanguloPiedra.width/2 );
int espacioDepredX = rectanguloDepred.x -  ( rectanguloDepred.width/2 );
int espacioPiedraY = this.spawn.y+ (rectanguloPiedra.height/2);
int espacioDepredY = rectanguloDepred.y - ( rectanguloDepred.width/2 );
	
if ( (espacioPiedraX >= espacioDepredX ) && ( espacioPiedraY >=  espacioDepredY ) ) {
	return true;		 
}
return false;	 
}

}
