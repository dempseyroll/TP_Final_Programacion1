package juego;

public class Temporizador {
	int minutos;
	int segundos;
	int miliSegundos;
	
	public Temporizador( int seg ){
		this.segundos= seg;
	}
	
	public void tiempo() {
		miliSegundos+=1550;
		segundos= miliSegundos/100000;
		
		if( segundos > 59 ) {
			minutos+=1;
			this.miliSegundos=0;
			this.segundos = 0;	
			if(minutos > 59) {
				minutos=0;
			}
		}
	}
}
