package juego;

import java.awt.*;
import entorno.*;

public class Pasto {
	Point punto;
	private Image pasto;
	
public Pasto(int x, int y) {
	this.punto = new Point(x,y);
	this.pasto = Herramientas.cargarImagen("pastoFijo-2.png");
}

public void dibujarse(Entorno entorno) {
	entorno.dibujarImagen(pasto, punto.x, 620, 0, 1.5);
}

void moverIzquierda() {
	this.punto.x -=1.5;
	}
}